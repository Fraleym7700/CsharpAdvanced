﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace ConsoleUI
{
    /*
     Michael Fraley
     Mr Buckwell 
     C#Advanced

         */
    class Program
    {
        static void Main(string[] args)
        {
            bool looper = false;
            do
            {
                RandomNumberCreation();
                LetUserKnowAboutReadingFromLine();
                ReadFilePath();
                looper = reuse(looper);


            }
            while (looper == false);
        }

        private static void LetUserKnowAboutReadingFromLine()
        {
            Console.WriteLine("Now we are going to read from that file, and add the numbers and count how many items were created\nPress enter to continue");
            Console.ReadLine();
        }

        private static void ReadFilePath()
        {
            string filePath = "Random.txt";
            List<string> lines = File.ReadAllLines(filePath).ToList();
            foreach (string line in lines)
            {
                Console.WriteLine(line);
            }

            int total = lines.Sum(x => Convert.ToInt32(x));
            int count = lines.Count();
            Console.WriteLine($"The Total numbers added together = {total}");
            Console.WriteLine($"The number of random numbers reads from the file = {count}");
            Console.ReadLine();
        }

        private static bool reuse(bool looper)
        {
            Console.WriteLine("Would you to use this program again?");
            string reply = Console.ReadLine().ToLowerInvariant();
            if (reply == "yes"|| reply == "y")
            {
                looper = false;
            }
            else if (reply == "no" || reply == "n")
            {
                looper = true;
            }

            return looper;
        }





        private static void RandomNumberCreation()
        {
           
                //Create random
                Random Rand = new Random();
                //Create outputfile
                StreamWriter outputFile;
                outputFile = File.CreateText("Random.txt");

                //inititae question
                Console.WriteLine("This is a program that will put a list of random numbers in a text file \n ");
                //recieve answer
                int number = GetValue("how many random numbers would you like to put->");
                //for loop the random numbers
                for (int count = 0; count < number; count++)
                {
                    // Get random integers and assign them to randomNumber.
                    int randomNumber = (Rand.Next(1, 101));

                    // Write data to the file.
                    outputFile.WriteLine(randomNumber);


                }
            // Close the file outside for loop
                Console.WriteLine("Congratulations, your file has been saved in a text file called Random.txt\n\n");
            
                outputFile.Close();
                
             
           
            
        }




        public static int GetValue(string prompt)
        {
            while (true)
            {
                Console.WriteLine(prompt);
                string input = Console.ReadLine();
                int value;
                if (int.TryParse(input, out value))
                {
                    if (value <= 0)
                        Console.WriteLine("Please enter a positive number.");
                    else
                        return value;
                }
                else
                {
                    Console.WriteLine("Please enter a number.");
                }
            }

        }
    }
}
