﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfCar
{
    /// <summary>
    /// Interaction logic for DriveTheCar.xaml
    /// </summary>
    public partial class DriveTheCar : Page
    {
        public DriveTheCar()
        {
            InitializeComponent();
        }

        private void SpeedUp_ButtonClicked(object sender, RoutedEventArgs e)
        {

            int maybe = Convert.ToInt32(Speedomiter.Text);
            maybe += 5;
            Speedomiter.Text = Convert.ToString(maybe);
            

        }

        private void SlowDown_ButtonClicked(object sender, RoutedEventArgs e)
        {

            int maybe = Convert.ToInt32(Speedomiter.Text);
            maybe -= 5;
            Speedomiter.Text = Convert.ToString(maybe);


        }
    }
}
