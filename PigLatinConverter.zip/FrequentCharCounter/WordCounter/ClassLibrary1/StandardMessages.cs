﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class StandardMessages
    {
        public static string Menu()
        {
            return "1) Use Word Counter \n2) Use Average letter Counter \n3) Use Frequent Letter Counter \n4) Convert String to PigLatin \n5)Exit ";

        }
    }
}
