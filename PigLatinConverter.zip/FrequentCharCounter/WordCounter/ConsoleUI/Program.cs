﻿using System;
using static System.Console;
using System.Collections.Generic;
using ClassLibrary1;
using System.Collections.Generic;


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            void StringNumberOfLettersAndDigits()
            {

                WriteLine("Enter a string: ");
                var str = ReadLine();
                var dict = new Dictionary<string, int>();
                dict.Add("digit", 0);
                dict.Add("letter", 0);
                foreach (var c in str)
                    if (char.IsLetter(c))
                        dict["letter"]++;
                    else if (char.IsDigit(c))
                        dict["digit"]++;

                WriteLine("letters: " + dict["letter"]);
                WriteLine("digits: " + dict["digit"]);
                ReadLine();
            }
            void WordCounter()
            {
                string str;
                int count = 1, len = 0;
                WriteLine("Enter a string : ");
                str = ReadLine();

                while (len <= str.Length - 1)
                {
                    if (str[len] == ' ' || str[len] == '\n' || str[len] == '\t')
                    {
                        count++;
                    }
                    len++;
                }
                WriteLine("Total Number of words " + count);
                ReadLine();

            }

            void mostRepeated()
            {
                string s;
                WriteLine("Enter a string : ");
                s = ReadLine();

                int[] count = new int[256];
                int max = 0;
                Char result = Char.MinValue;

                Array.Clear(count, 0, count.Length - 1);

                foreach ( Char c in s)
                {
                    if(++count[c] > max)
                    {
                        max = count[c];
                        result = c;
                    }
                }
                WriteLine($"Most repeated Char in the string is {result}");
                ReadLine();
                

            }

            void ToPigLatin()
            {
                WriteLine("Enter a sentence to convert to PigLatin:");
                string str = ReadLine();

                const string vowels = "AEIOUaeio";
                List<string> pigLatinWords = new List<string>();

                foreach (string word in str.Split(' '))
                {
                    string firstLetter = word.Substring(0, 1);
                    string restOfWord = word.Substring(1, word.Length - 1);
                    int currentLetter = vowels.IndexOf(firstLetter);

                    if (currentLetter == -1)
                    {
                        pigLatinWords.Add(restOfWord + firstLetter + "ay");
                    }
                    else
                    {
                        pigLatinWords.Add(word + "way");
                    }
                }
                WriteLine(string.Join(" ", pigLatinWords));
                ReadLine();
            }



            bool looper = false;
            do
            {
                WriteLine(StandardMessages.Menu());
                string input = ReadLine();
                switch (input)
                {
                    case "1":
                        WordCounter();
                        break;

                    case "2":
                        StringNumberOfLettersAndDigits();
                        break;
                    case "3":
                        mostRepeated();
                        break;
                    case "4":
                        ToPigLatin();
                        break;
                    case "5":
                        looper = true;
                        break;
                    default:
                        WriteLine("Not the right answer");
                        break;
                }
            }
            while (looper == false);



        }
    }
}
