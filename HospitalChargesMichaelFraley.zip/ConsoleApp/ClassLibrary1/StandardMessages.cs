﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1
{
    public class StandardMessages
    {
        public static string HospitalMenu()
        {
            return "1) Create Hospital Bill\n2)Exit ";

        }
        public static int CreateDaysSpentinHospital()
        {
            Console.WriteLine("Enter days spent in hospital: ");
            int daysSpentinHospital = Convert.ToInt32(Console.ReadLine());
            return daysSpentinHospital;

        }
        public static int CreateMedicineCharges()
        {
            Console.WriteLine("Enter amount of medication charges: ");
            int medicineCharge = Convert.ToInt32(Console.ReadLine());
            return medicineCharge;

        }
        public static int CreateSurgicalCharges()
        {
            Console.WriteLine("Enter surgical charges: ");
            int surgicalCharge = Convert.ToInt32(Console.ReadLine());
            return surgicalCharge;

        }

        public static int CreateLabFees()
        {
            Console.WriteLine("Enter LabFees: ");
            int labFees = Convert.ToInt32(Console.ReadLine());
            return labFees;

        }

        public static int CreatePhysicalRehabFees()
        {
            Console.WriteLine("Enter the amount of physical rehabilition charges");
            int physicalRehabFees = Convert.ToInt32(Console.ReadLine());
            return physicalRehabFees;
        }


    }
}

