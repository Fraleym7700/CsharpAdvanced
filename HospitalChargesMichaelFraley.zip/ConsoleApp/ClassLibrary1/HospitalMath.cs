﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1
{
    /*create an application that calculates the total cost of a hospital stay.the application should accept the following input:

- the number of days spent in the hospital
- the amount of medication charges
   - the amount of surgical charges
   - the amount of lab fees
   - the amount of physical rehabilitation charges
   

   the hospital charges $350 per day.


   create the following methods:


   calcstaycharges calculates and returns the base charges for the hospital stay.the is compound as $350 times the number of days in the hospital.


   calcmisccharges calculates and returns the total of the medication, surgical, lab, and physical rehabilitation charges.


   calctotalcharges calculates and returns the total charges.*/
    public class HospitalMath
    {
        public static int CalculateBaseCharges(int daysSpentinHospital)
        {
            int baseCharge = daysSpentinHospital * 350;
            return baseCharge;
        }

        public static int CalculateMiscCharges(int medication, int surgical, int lab, int physical)
        {
            int miscCharge = medication + surgical + lab + physical;
            return miscCharge;
        }

        public static int CalculateTotalCharges(int baseCharge, int miscCharge)
        {
            int total = miscCharge + baseCharge;
            return total;

        }
    }

}
