﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1
{
    /*create an application that calculates the total cost of a hospital stay.the application should accept the following input:

- the number of days spent in the hospital
- the amount of medication charges
   - the amount of surgical charges
   - the amount of lab fees
   - the amount of physical rehabilitation charges
   

   the hospital charges $350 per day.


   create the following methods:


   calcstaycharges calculates and returns the base charges for the hospital stay.the is compound as $350 times the number of days in the hospital.


   calcmisccharges calculates and returns the total of the medication, surgical, lab, and physical rehabilitation charges.


   calctotalcharges calculates and returns the total charges.*/
    public class HospitalProperties
    {
        public int daysSpentinHospital;
        public int surgicalCharges;
        public int labFees;
        public int physicalRehabCharges;
        public int medication;

        public HospitalProperties(int daysSpentinHospital, int surgicalCharges, int labFees, int physicalRehabCharges, int medication)
        {
            DaysSpentinHospital = daysSpentinHospital;
            SurgicalCharges = surgicalCharges;
            LabFees = labFees;
            PhysicalRehabCharges = physicalRehabCharges;
            Medication = medication;


        }
        public int DaysSpentinHospital
        {
            get
            {
                return daysSpentinHospital;
            }
            set
            {
                daysSpentinHospital = value;
            }
        }

        public int SurgicalCharges
        {
            get
            {
                return surgicalCharges;
            }
            set
            {
                surgicalCharges = value;
            }
        }
        public int LabFees
        {
            get
            {
                return labFees;
            }
            set
            {
                labFees = value;
            }
        }
        public int PhysicalRehabCharges
        {
            get
            {
                return physicalRehabCharges;
            }
            set
            {
                physicalRehabCharges = value;
            }
        }
        public int Medication
        {
            get
            {
                return medication;
            }
            set
            {
                medication = value;
            }
        }


    }
}
