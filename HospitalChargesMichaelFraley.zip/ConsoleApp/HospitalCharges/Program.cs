﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;
/*create an application that calculates the total cost of a hospital stay.the application should accept the following input:

- the number of days spent in the hospital
- the amount of medication charges
   - the amount of surgical charges
   - the amount of lab fees
   - the amount of physical rehabilitation charges
   

   the hospital charges $350 per day.


   create the following methods:


   calcstaycharges calculates and returns the base charges for the hospital stay.the is compound as $350 times the number of days in the hospital.


   calcmisccharges calculates and returns the total of the medication, surgical, lab, and physical rehabilitation charges.


   calctotalcharges calculates and returns the total charges.*/
namespace HospitalCharges
{
   
    class Program
    {
        static void Main(string[] args)
        {
            bool looper = false;
            do
            {
                Console.WriteLine(StandardMessages.HospitalMenu());
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":

                        int days = StandardMessages.CreateDaysSpentinHospital();
                        int labs = StandardMessages.CreateLabFees();
                        int medicine = StandardMessages.CreateMedicineCharges();
                        int surgical = StandardMessages.CreateSurgicalCharges();
                        int physical = StandardMessages.CreatePhysicalRehabFees();

                        HospitalProperties bill = new HospitalProperties(days, surgical, labs, physical, medicine);
                        int baseCharges = HospitalMath.CalculateBaseCharges(days);
                        int miscCharges = HospitalMath.CalculateMiscCharges(medicine, surgical, labs, physical);
                        int total = HospitalMath.CalculateTotalCharges(baseCharges, miscCharges);
                        Console.WriteLine($"Base charges = {baseCharges}\nMiscCharges = {miscCharges}\nTotal = {total}");
                        break;
                    case "2":
                        looper = true;
                        break;
                    default:
                        Console.WriteLine("Looking forward to the Weekend.");
                        break;
                }
            }
            while (looper == false);


        }
    }
}
