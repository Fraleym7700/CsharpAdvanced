﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using ShapesLibrary;

namespace ShapesInheritance
{/*Write a Class that has three overloaded static methods for calculating the area of the following shapes:

Circles
Rectangles
Cylinders
Here are the formulas for calculating the area of the shapes.

Area of a circle: Area =  

, where p is Math.PI and r is the circle's radius
Area of a rectangle: Area = Width X Length

Area of a cylinder:  

, where p is Math.PI, r is the radius of the cylinder's base, and h is the cylinder's height
Because the three methods are to be overloaded, they should each have the same name, but different parameter lists. Demonstrate the class in a complete application.*/
    class Program
    {
        static void Main(string[] args)
        {
          
            Shape[] shapes = {new Circle(10),
            new Rectangle(4,5),
            new Cylander(3,9)};

         
            foreach (Shape s in shapes)
            {
                // Call the overidden method
                s.GetInfo();

                Console.WriteLine("{0} Area : {1:f2}",
                s.Name, s.Area());

                // check if an object is of a specific type
               
                Circle testCirc = s as Circle;
                if (testCirc == null)
                {
                    Console.WriteLine("This isn't a Circle");
                }

                // check the data type
                
                if (s is Circle)
                {
                    Console.WriteLine("This isn't a Rectangle");
                }


                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
