﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShapesLibrary
{
    public class Cylander : Shape
    {
        public double Radius { get; set; }
        public double Height { get; set; }

        public Cylander(double radius, double height)
        {
            Name = "Cylander";
            Radius = radius;
            Height = height;

        }

        public override double Area()
        {
            return 2 *Math.PI * (Math.Pow(Radius, 2.0)) + Height * (2 * Math.PI * Radius);
        }

        // replace the method using override
        public override void GetInfo()
        {
            // Execute the base version
            base.GetInfo();
            Console.WriteLine($"It has a Radius of {Radius} and the Height of {Height}");
        }

    
    }

}
