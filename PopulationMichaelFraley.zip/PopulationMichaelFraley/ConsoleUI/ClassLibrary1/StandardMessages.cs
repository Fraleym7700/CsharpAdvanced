﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;


namespace ClassLibrary1
{/*
A bacteriologist determines that the approximate final population of bacteria present in a culture after time (in days) is given by the following formula:
FinalPopulation = InitialPopulation * e(GrowthRate * Time)
Where InitialPopulation is the number present at the beginning of the observation period (Note: InitialPopulation does not change in value).
Let the user input the InitialPopulation, which is the number of bacteria present at the beginning of the trial and the GrowthRate (as a percentage).
Then compute the number of bacteria in the culture after each day for the first 10 days (Time will have values 1 through 10).
Do this in a loop so the user can see the results in a table (properly format your table with column headers and title). 
The output table should have headings for Da and Number of Bacteria Present (on that day. Every day should be displayed.*/

    public class StandardMessages
    {
        public static string CultureMenu()
        {
            return "1) Use Culture Formula\n2)Exit ";
        }

        public static double GetInitialPopulation()
        {
            WriteLine("Enter the initial population ->");
            double initialPop = Convert.ToDouble(ReadLine());
            return initialPop;
        }
        public static double GetGrowthRate()
        {
            WriteLine("Enter the GrowthRate ->");
            double growthRate = Convert.ToDouble(ReadLine());
            return growthRate;
        }

        public static double GetTime()
        {
            WriteLine("Enter the Time ->");
            double timeOfGrowth = Convert.ToDouble(ReadLine());
            return timeOfGrowth;
        }

        public static double FinalPopulation(double initialPop ,double time, double growth)
        {
            double exponent = growth * time;
            double Final = Math.Pow(initialPop, exponent);
            return Final;
        }

    }
}
