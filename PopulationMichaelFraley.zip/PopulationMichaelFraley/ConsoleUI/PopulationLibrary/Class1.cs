﻿using System;

namespace PopulationLibrary
{
    public class Class1
    {
    }
}
