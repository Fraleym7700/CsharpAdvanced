﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Population
{/*
A bacteriologist determines that the approximate final population of bacteria present in a culture after time (in days) is given by the following formula:
FinalPopulation = InitialPopulation * e(GrowthRate * Time)
Where InitialPopulation is the number present at the beginning of the observation period (Note: InitialPopulation does not change in value).
Let the user input the InitialPopulation, which is the number of bacteria present at the beginning of the trial and the GrowthRate (as a percentage).
Then compute the number of bacteria in the culture after each day for the first 10 days (Time will have values 1 through 10).
Do this in a loop so the user can see the results in a table (properly format your table with column headers and title). 
The output table should have headings for Da and Number of Bacteria Present (on that day. Every day should be displayed.*/
    class Program
    {
        static void Main(string[] args)
        {
             
        }
    }
}
