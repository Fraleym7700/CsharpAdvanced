﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DistanceLib;
using System.IO;
namespace Distance_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamWriter outputFile;
            outputFile = File.CreateText("DistanceCalculator.txt");
            try
            {
                bool looper = false;
                do
                {
                    Console.WriteLine(StandardMessages.DistanceMenu());
                    string input = Console.ReadLine();
                    switch (input)
                    {
                        case "1":

                            int speed = StandardMessages.FindCarSpeed();
                            int time = StandardMessages.findCarTime();
                            CarProperties Car = new CarProperties(speed, time);
                            int distance = DistanceMath.CalculateDistance(Car.speed, Car.time);
                            outputFile.WriteLine($"The Distance you went was {distance} Miles Per Hour");
                            outputFile.Close();
                            Console.ReadLine();
                            break;
                        case "2":
                            looper = true;
                            break;
                        default:
                            Console.WriteLine("Not a correct choice");
                            break;
                    }
                }
                while (looper == false);
            }
            catch(Exception ex)
            {
                outputFile.WriteLine(ex.Message);
            }

        }
    
    }
}
