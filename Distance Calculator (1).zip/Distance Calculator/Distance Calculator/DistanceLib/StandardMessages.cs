﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DistanceLib
{
    public class StandardMessages
    {
        /*If you know a vehicle's speed and amount of time it has traveled, you can calculate the distance it has traveled as follows:

Distance = Speed X time

For example, if a train travels 40 miles per hour for 3 hours, the distance traveled is 120 miles.

Create an application that asks the user for speed and then for a time. The program should return the distance traveled in an understandable format.*/

        public static string DistanceMenu()
        {
            return "1)Find Distance Speed \n2)Exit ";

        }
        public static int FindCarSpeed()
        {
            int speedofCar = GetValue("Enter Speed the car was going: ");
            //int speedofCar = Convert.ToInt32(Console.ReadLine());
            return speedofCar;

        }
        public static int findCarTime()
        {
            int timeCar = GetValue("Enter the amount of time the car was driving: ");
            //int timeCar = Convert.ToInt32(Console.ReadLine());
            return timeCar;

        }
        public static int GetValue(string prompt)
        {
            while (true)
            {
                Console.WriteLine(prompt);
                string input = Console.ReadLine();
                int value;
                if (int.TryParse(input, out value))
                {
                    if (value <= 0)
                        Console.WriteLine("Please enter a positive number.");
                    else
                        return value;
                }
                else
                {
                    Console.WriteLine("Please enter a number.");
                }
            }

        }

    }
}

