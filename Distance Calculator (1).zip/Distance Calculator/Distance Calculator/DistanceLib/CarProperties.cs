﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DistanceLib
{
    /*If you know a vehicle's speed and amount of time it has traveled, you can calculate the distance it has traveled as follows:

Distance = Speed X time

For example, if a train travels 40 miles per hour for 3 hours, the distance traveled is 120 miles.

Create an application that asks the user for speed and then for a time. The program should return the distance traveled in an understandable format.*/
    public class CarProperties
    {
        public int speed;
        public int time;
        

        public CarProperties(int speed, int time)
        {
            Speed = speed;
            Time = time;


        }
        public int Speed
        {
            get
            {
                return speed;
            }
            set
            {
                speed = value;
            }
        }

        public int Time
        {
            get
            {
                return time;
            }
            set
            {
                time = value;
            }
        }
       


    }
}
