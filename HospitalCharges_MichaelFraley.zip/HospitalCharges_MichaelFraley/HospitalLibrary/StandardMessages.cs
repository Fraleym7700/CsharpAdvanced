﻿using System;

namespace HospitalLibrary
{
    public class StandardMessages
    {
        public static string HospitalMenu()
        {
            return "1) Create Hospital Bill\n2)Exit ";

        }
        public static double CreateDaysSpentinHospital()
        {
            
            double daysSpentinHospital = GetValue("Enter days spent in hospital: ");
            return daysSpentinHospital;

        }
        public static double CreateMedicineCharges()
        {
      
            double medicineCharge = GetValue("Enter amount of medication charges: ");
            return medicineCharge;

        }
        public static double CreateSurgicalCharges()
        {
           
            double surgicalCharge = GetValue("Enter surgical charges: ");
            return surgicalCharge;

        }

        public static double CreateLabFees()
        {
            double labFees = GetValue("Enter LabFees: ");
            return labFees;

        }

        public static double CreatePhysicalRehabFees()
        {
            
            double physicalRehabFees = GetValue("Enter the amount of physical rehabilition charges");
            return physicalRehabFees;
        }

        public static double GetValue(string prompt)
        {

            Console.WriteLine(prompt);
            while (true)
            {
                string input = Console.ReadLine();
                double value;
                if (double.TryParse(input, out value))
                {
                    if (value <= 0)
                        Console.WriteLine("Please enter a positive number.");
                    else
                        return value;
                }
                else
                {
                    throw new ArgumentException("The number you added wasn't a number", "input");
                }
            }



        }

        public static double ValidateNumber(string input)
        {
            while (true)
            {
                double value;
                if (double.TryParse(input, out value))
                {
                    if (value <= 0)
                        Console.WriteLine("Please enter a positive number.");
                    else
                        return value;
                }
                else
                {
                    throw new ArgumentException("The number you added wasn't a number", "input");
                }
            }

        }
    }
}

