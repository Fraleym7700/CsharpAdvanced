﻿namespace HospitalLibrary
{
    /*create an application that calculates the total cost of a hospital stay.the application should accept the following input:

- the number of days spent in the hospital
- the amount of medication charges
   - the amount of surgical charges
   - the amount of lab fees
   - the amount of physical rehabilitation charges
   

   the hospital charges $350 per day.


   create the following methods:


   calcstaycharges calculates and returns the base charges for the hospital stay.the is compound as $350 times the number of days in the hospital.


   calcmisccharges calculates and returns the total of the medication, surgical, lab, and physical rehabilitation charges.


   calctotalcharges calculates and returns the total charges.*/
    public class HospitalProperties
    {
        public double daysSpentinHospital;
        public double surgicalCharges;
        public double labFees;
        public double physicalRehabCharges;
        public double medication;

        public HospitalProperties(double daysSpentinHospital, double surgicalCharges, double labFees, double physicalRehabCharges, double medication)
        {
            DaysSpentinHospital = daysSpentinHospital;
            SurgicalCharges = surgicalCharges;
            LabFees = labFees;
            PhysicalRehabCharges = physicalRehabCharges;
            Medication = medication;


        }
        public double DaysSpentinHospital
        {
            get
            {
                return daysSpentinHospital;
            }
            set
            {
                daysSpentinHospital = value;
            }
        }

        public double SurgicalCharges
        {
            get
            {
                return surgicalCharges;
            }
            set
            {
                surgicalCharges = value;
            }
        }
        public double LabFees
        {
            get
            {
                return labFees;
            }
            set
            {
                labFees = value;
            }
        }
        public double PhysicalRehabCharges
        {
            get
            {
                return physicalRehabCharges;
            }
            set
            {
                physicalRehabCharges = value;
            }
        }
        public double Medication
        {
            get
            {
                return medication;
            }
            set
            {
                medication = value;
            }
        }


    }
}
