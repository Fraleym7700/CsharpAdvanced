﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HospitalLibrary.test
{
    [TestClass]
    public class standardMessagesTest
    {
        
        [TestMethod]
        public void Validate_NumberShouldValidate()
        {
            //Arragne
            string input = "100";

            //Act
            double actual = StandardMessages.ValidateNumber(input);

            //Assert
            Assert.IsTrue(actual >= 0);
        }

        [TestMethod]
        public void Validate_NumberShouldThrowException()
        {
            //Arragne
            string input = "YabbaDabbaDoo";


            //Act and Assert
            Assert.ThrowsException<System.ArgumentException>(() => StandardMessages.ValidateNumber(input));
        }
    }
}
