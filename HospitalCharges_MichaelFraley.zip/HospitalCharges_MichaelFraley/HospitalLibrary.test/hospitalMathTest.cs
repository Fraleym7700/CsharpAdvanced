﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HospitalLibrary;


namespace HospitalLibrary.test
{
    [TestClass]
    public class hospitalMathTest
    {
        [TestMethod]
        public void CalculateBaseCharges_ShouldCalculate()
        {
            // Arrange
            /*
            int baseCharge = daysSpentinHospital * 350;
            return baseCharge;*/


            // Act
            double expected = 365 * 350;

            // Assert
            double actual = HospitalMath.CalculateBaseCharges(365);
            Assert.AreEqual(expected, actual);
        }

        public void CalculateMiscCharges_ShouldCalculate()
        {

            // Arrange
            double medication = 35;
            double surgical = 350;
            double lab = 200;
            double physical = 50;

            // Act
            double expected = 35+350+200+50;

            // Assert
            double actual = HospitalMath.CalculateMiscCharges(medication,surgical,lab,physical);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CalculateTotalCharges_ShouldCalculate()
        {
            // Arrange
            /*
            public static double CalculateTotalCharges(double baseCharge, double miscCharge)
        {
            double total = miscCharge + baseCharge;
            return total;

        };*/

            double basecharge = 2000;
            double miscCharge = 1500;
            // Act
            double expected = 3500;

            // Assert
            double actual = HospitalMath.CalculateTotalCharges(basecharge,miscCharge);
            Assert.AreEqual(expected, actual);
        }
    }
}
