﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailPriceLib;


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("After the markup, the total value is --> $" + Calculator.CalculateRetail());
        }
        
    }
}
