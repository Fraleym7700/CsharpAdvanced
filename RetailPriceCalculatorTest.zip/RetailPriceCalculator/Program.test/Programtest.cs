﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailPriceLib;
using Xunit;
using Xunit.Sdk;

namespace Program.test
{
    public class Programtest
    {
        


        
        [Theory]
        [InlineData("1")]
        public void validateNumber_ShouldReturnOnlyNumbers(string input)
        {
      
            //Act
            double actual = Calculator.ValidateNumber(input);
            //Assert
            Assert.True(actual >= 0);
        }
    }
}
