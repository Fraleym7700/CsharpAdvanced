using Microsoft.VisualStudio.TestTools.UnitTesting;
using RetailPriceLib;
using System.Transactions;

namespace RetailPriceLib.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Validate_NumberShouldValidate ()
        {
            //Arragne
            string input = "100";

            //Act
            int actual = Calculator.ValidateNumber(input);

            //Assert
            Assert.IsTrue(actual >= 0);
        }

        [TestMethod]
        public void Validate_NumberShouldThrowException()
        {
            //Arragne
            string input = "YabbaDabbaDoo";
            

            //Act and Assert
            Assert.ThrowsException<System.ArgumentException> (() => Calculator.ValidateNumber(input));
        }

        [TestMethod]
        public void markUpPercent_shouldbeCorrect()
        {
            //Arragne

            //200 / 100
            double expected = 2;

            double markup = 200;

            //Act
            double actual = Calculator.GetMarkupPercent(markup);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void getRetail_shouldbeCorrect()
        {
            //Arragne
            //500 +(500 * 2)
            double expected = 1500;

            //Act
            double markup = 200;
            double markupPercent = Calculator.GetMarkupPercent(markup);
            double wholesale = 500;
            double actual = Calculator.GetRetailPrice(wholesale, markupPercent);

            //Assert
            Assert.AreEqual(expected, actual);
        }

    }
}
