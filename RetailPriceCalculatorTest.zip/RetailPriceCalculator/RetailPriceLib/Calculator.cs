﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailPriceLib
{
   public class Calculator
    {
        public static double CalculateRetail()
        {

            double retailPrice;
            double wholesale;
            double markup;
            wholesale = GetWholeSalePrice();
            markup = GetMarkUpPrice();
            double markupPercent = GetMarkupPercent(markup);
            retailPrice = GetRetailPrice(wholesale, markupPercent);
            return retailPrice;

        }

        public static double GetRetailPrice(double wholesale, double markupPercent)
        {
            return wholesale + (wholesale * markupPercent);
        }

        public static double GetMarkupPercent(double markup)
        {
            return markup / 100;
        }

        public static double GetMarkUpPrice()
        {
            return Convert.ToDouble(GetValue("Enter the markup percentage you would like to enter"));
        }

        public static double GetWholeSalePrice()
        {
            return Convert.ToDouble(GetValue("Enter the value of the item"));
        }

        public static int GetValue(string prompt)
        {
            
            Console.WriteLine(prompt);
            while (true)
            {
                string input = Console.ReadLine();
                int value;
                if (int.TryParse(input, out value))
                {
                    if (value <= 0)
                        Console.WriteLine("Please enter a positive number.");
                    else
                        return value;
                }
                else
                {
                    throw new ArgumentException("The number you added wasn't a number", "input");
                }
            }



        }

        public static int ValidateNumber(string input)
        {
            while (true)
            {
                int value;
                if (int.TryParse(input, out value))
                {
                    if (value <= 0)
                        Console.WriteLine("Please enter a positive number.");
                    else
                        return value;
                }
                else
                {
                    throw new ArgumentException("The number you added wasn't a number", "input");
                }
            }
            
        }
    }
}
